CREATE TABLE docentes (
    rut VARCHAR(12) PRIMARY KEY,
    nombre VARCHAR(150),
    correo VARCHAR(100),
    cargo VARCHAR(50),
    estamento VARCHAR(50)
);