Este es el repositorio del Grupo 06, cuyos integrantes son:

* Benjamín Carvajal 202273099-4
* Cristóbal Castro 202273118-4
* Matias Correa 202273136-2
* Nicolas Guerrero 202330023-3
* **Tutor**: Valentina Castillo

## Wiki

Puede acceder a la Wiki mediante el siguiente [enlace](https://gitlab.com/Criscool11/grupo06-2025-proyinf/-/wikis/home)

# INF236-2025-1-Proyecto Base

## Aspectos técnicos relevantes

_Todo aspecto relevante cuando para poder usar el proyecto o consideraciones del proyecto base a ser entregado_

_Nada por el momento..._

## Requerimientos

Para utilizar el proyecto base debe tener instalado [Node.js](https://nodejs.org/en), [Docker](https://www.docker.com/) y se recomienda [Postman](https://www.postman.com/) para poder probar los endpoints de las APIs.