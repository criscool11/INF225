#CREATE DATABASE IF NOT EXISTS pmc;
#USE pmc;

CREATE TABLE IF NOT EXISTS colegios (
  rbd INT PRIMARY KEY,
  nombre VARCHAR(100),
  sigla VARCHAR(20),
  genero VARCHAR(20),
  director VARCHAR(100),
  direccion VARCHAR(150),
  comuna VARCHAR(50),
  region VARCHAR(50),
  vigente BOOLEAN
);