CREATE TABLE cursos (
    codigo_curso VARCHAR(20) PRIMARY KEY,
    agno INTEGER,
    nivel VARCHAR(50),
    letra VARCHAR(5),
    cantidad_alumnos INTEGER,
    tipo_ensenanza VARCHAR(100),
    tipo_nivel VARCHAR(50),
    colegio INTEGER,
    rut_profesor_jefe VARCHAR(12),
    FOREIGN KEY (colegio) REFERENCES colegios(rbd)
);